# -*- coding: utf-8 -*-
import os

APP_PATH = os.path.dirname(__file__)
DB_FILE = APP_PATH + "/data/sshclient.db"

# Password crypts
APP_KEY = '325f8fba4b213fced0d3dd0f82de103f'
IV_KEY = '98a018c90b24aa94'
