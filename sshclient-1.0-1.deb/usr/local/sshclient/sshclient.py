#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from windows.main_window import MainWindow

# Start the Main Window
MainWindow()
