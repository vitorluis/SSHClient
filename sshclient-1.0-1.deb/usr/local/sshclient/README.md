# SSHClient

SSHClient is a software written in Python using GTK+.
The main purpose of this project is to manage SSH connection via GUI.

With some click you are able to add a new SSH connection and open this connection via Shell.
You also can add tunnels on this connection, so in connection time, the tunnels will be opened.

And you can edit and delete this connection. So, all connection can be managed in one place, simple
and fast


